<?php
header('Content-Type: text/html; charset=utf-8');
$rates = ['EUR' => 4.50, 'GBP' => 5.40];
$amount = isset($_POST['amount']) ? str_replace(',', '.', trim($_POST['amount'])) : '';
$currency = isset($_POST['currency']) ? $_POST['currency'] : '';
if ($amount === '' || !is_numeric($amount) || !isset($rates[$currency])) {
    echo '<!doctype html><html lang="pl"><head><meta charset="utf-8"><title>Błąd</title></head><body>';
    echo '<p>Błąd danych. <a href="index.html">Wróć do formularza</a></p>';
    echo '</body></html>';
    exit;
}
$converted = (float)$amount / $rates[$currency];
?>
<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <title>Wynik przeliczenia</title>
</head>
<body>
  <p><?php echo number_format((float)$amount, 2, ',', ' '); ?> PLN =
     <strong><?php echo number_format($converted, 2, ',', ' '); ?> <?php echo htmlspecialchars($currency); ?></strong></p>
</body>
</html>