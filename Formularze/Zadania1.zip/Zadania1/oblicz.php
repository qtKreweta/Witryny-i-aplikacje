<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oblicz</title>
</head>
<body>
    
<?php
$lin = isset($_POST['linnie']) ? (int)$_POST['linnie'] : 0;
$kra  = isset($_POST['kratka']) ? (int)$_POST['kratka'] : 0;
$smo  = isset($_POST['smooth']) ? (int)$_POST['smooth'] : 0;

$lin = max(0, $lin);
$kra  = max(0, $kra);
$smo  = max(0, $smo);

$koszt = $lin * 1.5 + $kra * 1.3 + $smo * 1;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Kasa biletowa</title>
<style>
#kontener { 
    width:550px; 
}
#blok { 
    width:350px; 
    float:left; 
}
</style>
</head>
<body>
<div id="kontener">
  <div id="blok">
<?php
echo "<p>Dokonałeś następującego zamówienia: </p>";
$lin = (int)$_POST['linnie'];
$kra  = (int)$_POST['kratka']; 
$smo  = (int)$_POST['smooth']; 
echo "<ul><li>Zesztyt w linnie: $lin sztuki</li>";
echo "<li>Zeszyty w kratkę: $kra sztuki</li>";
echo "<li>Zeszyty gładkie: $smo sztuki</li></ul>";
$koszt = $lin * 1.5 + $kra * 1.3 + $smo * 1;
echo "<h3>Koszt Twojego zamówienia wynosi: $koszt zl.</h3>";
?>

</body>
</html>